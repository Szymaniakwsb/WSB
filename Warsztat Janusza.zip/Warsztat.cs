﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Warsztat
    {
        static void Main()
        {
            int menu;

            Console.WriteLine("Wybierz jedno z poniższych");
            Console.WriteLine("1. Wyswietl liste pojazdow \n2. Dodaj nowy pojazd \n3. Wyszukaj pojazdy \n4. Sprzedaj pojazd");
            int.TryParse(Console.ReadLine(), out menu);
            List<Pojazd> lista = new List<Pojazd>();

            switch (menu)
            {
                case 1:
                    Console.WriteLine("Lista pojazdow");
                    break;
                case 2:
                    Console.WriteLine("Dodawanie nowego pojazdu");

                    int menu2;

                    Console.WriteLine("Wybierz jedno z poniższych");
                    Console.WriteLine("1. Podaj typ pojazdu \n2. Podaj model pojazdu \n3. Podaj rok produkcji pojazdu");
                    int.TryParse(Console.ReadLine(), out menu2);
                    // 
                    switch (menu2)
                    {
                        case 1:
                            Console.WriteLine("Typ pojazdu, wybierz jeden z ponizszych.");

                            int typ;

                            Console.WriteLine("1. Samochod \n2. Motocykl");
                            int.TryParse(Console.ReadLine(), out typ);
                            //
                            switch (typ)
                            {
                                case 1:
                                    Console.WriteLine("Wybierz marke samochodu");

                                    int marka;

                                    Console.WriteLine("1. Ford \n2. Fiat");
                                    int.TryParse(Console.ReadLine(), out marka);
                                    //
                                    switch (marka)
                                    {
                                        case 1:
                                            Console.WriteLine("Wybierz model Forda");

                                            int fordm;

                                            Console.WriteLine("1. Mustang \n2. Ranger");
                                            int.TryParse(Console.ReadLine(), out fordm);
                                            //
                                            switch (fordm)
                                            {
                                                case 1:
                                                    Console.WriteLine("Mustang");
                                                    //
                                                    break;
                                                case 2:
                                                    Console.WriteLine("Ranger");
                                                    //
                                                    break;
                                            }
                                            break;
                                        case 2:
                                            Console.WriteLine("Wybierz model Fiata");

                                            int fiatm;

                                            Console.WriteLine("1. Panda \n2. Multipla");
                                            int.TryParse(Console.ReadLine(), out fiatm);
                                            //
                                            switch (fiatm)
                                            {
                                                case 1:
                                                    Console.WriteLine("Panda");
                                                    //
                                                    break;
                                                case 2:
                                                    Console.WriteLine("Multipla");
                                                    //
                                                    break;
                                            }
                                            break;

                                    }
                                    break;
                            }
                            break;
                        case 2:
                            Console.WriteLine("Model pojazdu; wybierz jeden z ponizszych.");
                            break;

                    }
                    break;
                case 3:
                    Console.WriteLine("Wyszukiwanie pojazdu");
                    break;
                case 4:
                    Console.WriteLine("Sprzedawanie pojazdu");
                    break;

                    //lista ------------------------------
                    //int[] a = new int[100];            |
                    //List<int> a = new List<int>();     |
                    //a.add(...)                         |
                    //------------------------------------
            }
        }
    }
}
