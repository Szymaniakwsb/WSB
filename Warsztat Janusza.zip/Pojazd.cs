﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class Pojazd
    {
        private float fCenaZakupu;
        private float fMarza;
        private int iRokProdukcji;

        public float CenaZakupu
        {
            get
            {
                return fCenaZakupu;
            }
            
        }

        public float Marza
        {
            get
            {
                return fMarza;
            }
            set
            {
                if (float.IsNullOrEmpty(value))
                    throw new Exception("Błędna wartość pola Marza");
                fMarza = value;
            }
        }

        public int RokProdukcji
        {
            get
            {
                return iRokProdukcji;
            }
            set
            {
                if (iRokProdukcji < 0)
                    throw new Exception("Błędna wartość pola RokProdukcji");
                iRokProdukcji = value;
            }
        }

        public Pojazd()
        {
            fCenaZakupu = float.Empty;
            fMarza = float.Empty;
            iRokProdukcji = 0;
        }

        public override string ToString()
        {
            string formattedAddress = "";

            if (!string.IsNullOrEmpty(fCenaZakupu))
                formattedAddress += $"{fCenaZakupu} ";

            if (!string.IsNullOrEmpty(fMarza))
                formattedAddress += $"{fMarza} ";

            if (iRokProdukcji > 0)
                formattedAddress += $"{iRokProdukcji}";

            return $"Dane samochodowe = {formattedAddress}";
        }
    }
}
